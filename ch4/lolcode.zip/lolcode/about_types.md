+++
date = "2016-05-05T08:41:21-04:00"
draft = true
title = ""
categories = ["Types"]
categories_weight = 1
+++

_(updated from 1.1)_

The variable types that LOLCODE currently recognizes are: strings (YARN), integers (NUMBR), floats (NUMBAR), and booleans (TROOF) (Arrays (BUKKIT) are reserved for future expansion.) Typing is handled dynamically. Until a variable is given an initial value, it is untyped (NOOB). <del>Casting operations operate on TYPE types, as well.</del>