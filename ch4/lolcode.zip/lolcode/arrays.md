+++
date = "2016-05-05T08:41:21-04:00"
draft = true
title = "Arrays"
categories = ["Types"]
categories_weight = 6
+++

_Array and dictionary types are currently under-specified. There is general will to unify them, but indexing and definition is still under discussion._