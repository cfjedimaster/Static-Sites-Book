+++
date = "2016-05-05T08:50:24-04:00"
draft = true
title = "Assignment Statements"
categories = ["Statements"]
categories_weight = 2
+++

Assignment statements have no side effects with `IT`. They are generally of the form:

``` html
<variable> <assignment operator> <expression>
```

The variable being assigned may be used in the expression.


