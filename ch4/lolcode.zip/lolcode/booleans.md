+++
date = "2016-05-05T08:41:21-04:00"
draft = true
title = "Booleans"
categories = ["Types"]
+++

The two boolean (TROOF) values are WIN (true) and FAIL (false). The empty string (""), an empty array, and numerical zero are all cast to FAIL. All other values evaluate to WIN.