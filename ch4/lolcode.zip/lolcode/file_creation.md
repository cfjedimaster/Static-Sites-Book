+++
date = "2016-05-04T17:35:01-04:00"
draft = true
title = "File Creation"
categories = ["formatting"]
categories_weight = 3
+++

_(modified from 1.1)_

All LOLCODE programs must be opened with the command `HAI`. `HAI` should then be followed with the current LOLCODE language version number (1.2, in this case). There is no current standard behavior for implementations to treat the version number, though.

A LOLCODE file is closed by the keyword `KTHXBYE` which closes the `HAI` code-block.