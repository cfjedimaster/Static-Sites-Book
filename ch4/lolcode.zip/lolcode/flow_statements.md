+++
date = "2016-05-05T08:50:24-04:00"
draft = true
title = "Flow Control Statements"
categories = ["Statements"]
categories_weight = 3
+++

Flow control statements cover multiple lines and are described in the following section.

