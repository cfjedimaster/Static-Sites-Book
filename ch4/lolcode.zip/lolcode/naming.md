+++
date = "2016-05-05T08:39:55-04:00"
draft = true
title = "Naming"
categories = ["Variables"]
categories_weight = 2
+++

_(from 1.1)_

Variable identifiers may be in all small or lowercase letters (or a mixture of the two). They must begin with a letter and may be followed only by other letters, numbers, and underscores. No spaces, dashes, or other symbols are allowed. Variable identifiers are CASE SENSITIVE – "cheezburger", "CheezBurger" and "CHEEZBURGER" would all be different variables.