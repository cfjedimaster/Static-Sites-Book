+++
date = "2016-05-05T08:39:55-04:00"
draft = true
title = "Scope"
categories = ["Variables"]
categories_weight = 1
+++

_(to be revisited and refined)_

All variable scope, as of this version, is local to the enclosing function or to the main program block. Variables are only accessible after declaration, and there is no global scope.