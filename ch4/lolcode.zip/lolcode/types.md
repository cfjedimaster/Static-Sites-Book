+++
date = "2016-05-05T08:41:21-04:00"
draft = true
title = "Types"
categories = ["Types"]
categories_weight = 7
+++

The TYPE type only has the values of TROOF, NOOB, NUMBR, NUMBAR, YARN, and TYPE, as bare words. They may be legally cast to TROOF (all true except for NOOB) or YARN.

_TYPEs are under current review. Current sentiment is to delay defining them until user-defined types are relevant, but that would mean that type comparisons are left unresolved in the meantime._