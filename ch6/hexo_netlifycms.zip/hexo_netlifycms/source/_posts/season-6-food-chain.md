---
layout: post
title:  "Food Chain (Season 6)"
date:   2014-06-12 10:33:56
categories: season6 episodes
shortdesc: Finn and Jake learn about the food chain by becoming the food chain.
banner: /assets/images/foodchain.jpg
---
The episode begins with candy children that have bodies resembling different shapes sliding down a slide, shouting with excitement. The kids are viewed from an horizontal angle in the next scene as they go through a playground-like structure.<!--more--> Finn and Jake are examining the 'Catapilla Family'. After watching Princess Bubblegum teach the children about the Food Chain, they head to the snack bar as Finn found Princess Bubblegum's class useless.

While they're walking Magic Man appears behind the two without them knowing, and transforms them into birds. After singing an electronic version of "[Der Hölle Rache kocht in meinem Herzen](http://adventuretime.wikia.com/wiki/Der_H%C3%B6lle_Rache_kocht_in_meinem_Herzen)," they fly down below to a place with an oasis on it. Jake eats some caterpillars, which disgusts Finn. After that Finn tries eating the caterpillars and pukes on the ground. In the next scene, Finn and Jake are shown to be very chubby and sitting on the ground lazily. Finn becomes confused for why he became full from eating few caterpillars. Jake informs him that they have been eating for hours. Soon, Finn and Jake notice a shadow on the ground that gradually becomes bigger. They look up to see a big bird trying to attack them. Finn and Jake dodge this attack and attempt to fly away. However, because of Finn's chubby body, Finn is not able to fly and skids across the ground. As the big bird flies closer, Finn cowers. The big bird does not recognize Finn and flies onward. As Finn tries to fly away, the big bird notices and flies towards him once again. Just as the big bird was close enough to strike, Magic Man converts Finn into the big bird.

Finn then flies next to Jake. Jake does not recognize him, stating him as big and old. Finn hallucinates Jake as meat. Finn drools awfully, and states that Jake looks awesome and tasty. Finn asks Jake if he wants to go inside his mouth. Jake accepts and sits in his mouth. He states that Finn has a lot of saliva. Finn tries to eat Jake before he could escape from Finn's mouth. Finn attempts again to eat him. Finn elevates lower until he hits the ground. He lays on the ground while the sun sets, stating how hungry he is, and dies.

However, Finn is turned into hundreds of bacteria. The bacteria notices the dead body of the big bird as food and eats it. Jake is also turned into a bacterium and states that Finn eating the big bird is disgusting. The bacteria becomes full after the big bird results as a skeleton. The bacteria is then swept away by a gust of wind. Finn and Jake then find themselves turned into flowers.

Finn and Jake sing "[We're Plants](http://adventuretime.wikia.com/wiki/We%27re_Plants)." during the song, caterpillars eat Finn and Jake's leaves. Small birds come to eat the caterpillars. Finn and Jake are then turned into caterpillars.

Finn and Jake spot [Erin](http://adventuretime.wikia.com/wiki/Erin) who faints from the heat. Finn crawls to Erin quickly, madly in love with her. Finn and Jake crawl with her in search of an oasis. Erin faints again, and Jake finds an oasis. Finn, Erin, and Jake eat the leaves in the oasis. After a short discussion, Erin and Finn decide to get married.

The scene changes into a leaf with a group of caterpillars with Jake hosting the marriage. Finn agrees to the marriage and everyone cheers. Suddenly, two birds are shown flying to the leaf, eating the caterpillars. Finn and Jake then changes into the birds eating the caterpillars until Finn was back into reality. Finn had caterpillars stuffed in his mouth in which he spitted them out.

Back into the reality, Finn realizes the lesson of the Food Chain and sings "[Food Chain](http://adventuretime.wikia.com/wiki/Food_Chain_(song))", which PB soon joins singing with him.

The end shows Finn transforming into a bird-caterpillar-plant-bacteria hybrid while the kids leave due to boredom, once again entering the slide seen in the beginning.